DailyCash KeyGen (owner tool) - offline activation-key generator.
Enter the customer's phone code + your OWNER private key (paste once, "Remember key") -> Generate key.
The app has no internet permission. The private key is NOT part of this project - never add it here.

GitHub build:
1. Secrets: KEYSTORE_B64, KS_PASS (same ones as the DailyCash repo).
2. Upload KeyGen-Upload.zip to the repo root (do not extract) + .github/workflows/build.yml
3. Actions > Build DailyCash KeyGen APK > Run workflow. APK: Releases page (or Actions > artifact).
